from py2neo import Graph, Node, Relationship
from pyswip import Prolog
from datetime import datetime
import aiml
import os

class SmartChatBot:
    def __init__(self):
        self.kernel = aiml.Kernel()
        if os.path.exists("bot_brain.brn"):
            self.kernel.bootstrap(brainFile="bot_brain.brn")
        else:
            self.kernel.learn("prolog.aiml")
            self.kernel.learn("semantic_memory.aiml")
            self.kernel.learn("sensory_memory.aiml")
            self.kernel.learn("Pam_memory.aiml")
            self.kernel.saveBrain("bot_brain.brn")

        self.prolog = Prolog()
        self.prolog.consult("relations_prolog.pl")

        self.graph = Graph("bolt://localhost:7687", auth=("neo4j", "123123123"))
        self.user_node = Node("User", email="voice_user")  # dummy voice user
        self.graph.merge(self.user_node, "User", "email")  # ensure it exists

    def run_prolog_query(self, query):
        try:
            result = list(self.prolog.query(query, maxresult=1))
            if result:
                if result == [{}]:
                    return "yes"
                else:
                    values = []
                    for row in result:
                        for key in row:
                            values.append(str(row[key]).capitalize())
                    return ", ".join(values)
            else:
                return "no"
        except Exception as e:
            print("Prolog error:", e)
            return "error"

    def get_memory_type(self, user_input):
        sensory_keywords = ["see", "saw", "heard", "sound", "smell", "felt", "taste", "touch"]
        episodic_keywords = ["when", "where", "time", "event", "happened"]
        if any(word in user_input.lower() for word in sensory_keywords):
            return "SensoryMemory"
        elif any(word in user_input.lower() for word in episodic_keywords):
            return "EpisodicMemory"
        elif "remember" in user_input.lower() or "recall" in user_input.lower():
            return "PAMMemory"
        elif any(word in user_input.lower() for word in ["friend", "family", "father", "mother", "who is"]):
            return "SocialMemory"
        else:
            return "SemanticMemory"

    def handle_command(self, user_input):
        response = ""
        kernel_response = self.kernel.respond(user_input)

        memory_type = self.get_memory_type(user_input)
        timestamp = datetime.now().isoformat()
        memory_node = Node(memory_type, text=user_input, timestamp=timestamp)
        self.graph.create(memory_node)
        self.graph.create(Relationship(self.user_node, "HAS_MEMORY", memory_node))

        if memory_type == "SocialMemory":
            prolog_query = self.kernel.getPredicate("query")
            if prolog_query:
                result = self.run_prolog_query(prolog_query)
                self.kernel.setPredicate("prolog_result", result)
                result_node = Node("Result", value=result, timestamp=timestamp)
                query_node = Node("SocialMemory", text=user_input, timestamp=timestamp)
                self.graph.create(result_node)
                self.graph.create(query_node)
                self.graph.create(Relationship(query_node, "RESULT_IS", result_node))
                self.graph.create(Relationship(self.user_node, "HAS_MEMORY", query_node))
                self.graph.create(Relationship(self.user_node, "ASKED", result_node))
                response = self.kernel.respond("PROLOG BOOLEAN" if result in ["yes", "no"] else "PROLOG ANSWER")
            else:
                response = kernel_response
        else:
            response = kernel_response

        return response
