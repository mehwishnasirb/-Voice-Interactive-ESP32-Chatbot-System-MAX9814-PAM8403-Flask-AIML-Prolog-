from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from py2neo import Graph, Node, Relationship
from pyswip import Prolog
import aiml
import os
from datetime import datetime
from uuid import uuid4

app = Flask(__name__)
app.secret_key = "some_secret_key"

graph = Graph("bolt://localhost:7687", auth=("neo4j", "123123123"))
kernel = aiml.Kernel()

if os.path.exists("bot_brain.brn"):
    kernel.bootstrap(brainFile="bot_brain.brn")
else:
    kernel.learn("prolog.aiml")
    kernel.learn("semantic_memory.aiml")
    kernel.learn("sensory_memory.aiml")
    kernel.learn("Pam_memory.aiml")
    kernel.saveBrain("bot_brain.brn")

prolog = Prolog()
prolog.consult("relations_prolog.pl")

def run_prolog_query(query):
    try:
        result = list(prolog.query(query, maxresult=1))
        if result:
            if result == [{}]:
                return "yes"
            else:
                values = []
                for row in result:
                    for key in row:
                        values.append(str(row[key]).capitalize())
                return ", ".join(values)
        else:
            return "no"
    except Exception as e:
        print("Prolog error:", e)
        return "error"

def is_logged_in():
    return "user_email" in session

@app.route("/")
def index():
    if not is_logged_in():
        return redirect(url_for("login"))
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    if not is_logged_in():
        return jsonify({"response": "Please log in to use the chatbot."})

    user_input = request.json.get("user_input")
    kernel_response = kernel.respond(user_input)
    print("AIML Kernel Response:", kernel_response)

    user_email = session["user_email"]
    user_node = graph.evaluate("MATCH (u:User {email: $email}) RETURN u", email=user_email)
    episode_id = session.get("episode_id")
    episode_node = graph.evaluate("MATCH (e:Episode {episode_id: $eid}) RETURN e", eid=episode_id)

    def get_memory_type(user_input):
        sensory_keywords = ["see", "saw", "heard", "sound", "smell", "felt", "taste", "touch"]
        episodic_keywords = ["when", "where", "time", "event", "happened"]
        if any(word in user_input.lower() for word in sensory_keywords):
            return "SensoryMemory"
        elif any(word in user_input.lower() for word in episodic_keywords):
            return "EpisodicMemory"
        elif "remember" in user_input.lower() or "recall" in user_input.lower():
            return "PAMMemory"
        elif any(word in user_input.lower() for word in ["friend", "family", "father", "mother", "who is"]):
            return "SocialMemory"
        else:
            return "SemanticMemory"

    def create_memory(memory_type, text):
        if not text:
            return None
        timestamp = datetime.now().isoformat()
        memory_node = Node(memory_type, text=text, timestamp=timestamp)
        graph.create(memory_node)
        graph.create(Relationship(user_node, "HAS_MEMORY", memory_node))
        if episode_node:
            msg_node = Node("Message", text=text, timestamp=timestamp)
            graph.create(msg_node)
            graph.create(Relationship(episode_node, "HAS_MESSAGE", msg_node))
        return memory_node

    memory_type = get_memory_type(user_input)
    memory_node = create_memory(memory_type, user_input)

    if memory_type == "SocialMemory":
        prolog_query = kernel.getPredicate("query")
        if prolog_query:
            result = run_prolog_query(prolog_query)
            kernel.setPredicate("prolog_result", result)
            result_node = Node("Result", value=result, timestamp=datetime.now().isoformat())
            query_node = Node("SocialMemory", text=user_input, timestamp=datetime.now().isoformat())
            graph.create(result_node)
            graph.create(query_node)
            graph.create(Relationship(query_node, "RESULT_IS", result_node))
            graph.create(Relationship(user_node, "HAS_MEMORY", query_node))
            graph.create(Relationship(user_node, "ASKED", result_node))
            response = kernel.respond("PROLOG BOOLEAN" if result in ["yes", "no"] else "PROLOG ANSWER")
        else:
            response = kernel_response
    else:
        response = kernel_response

    return jsonify({"response": response})

@app.route("/get_memories")
def get_memories():
    if not is_logged_in():
        return jsonify({"memories": []})
    user_email = session["user_email"]
    memories = graph.run("""
        MATCH (u:User {email: $email})-[:HAS_MEMORY]->(m)
        RETURN m.text AS text, m.timestamp AS time
        ORDER BY m.timestamp DESC
        LIMIT 5
    """, email=user_email).data()
    return jsonify({"memories": memories})

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "GET":
        return render_template("signup.html")
    name = request.form["name"]
    email = request.form["email"]
    phone = request.form.get("phone")
    password = request.form["password"]
    existing_user = graph.evaluate("MATCH (u:User {email: $email}) RETURN u", email=email)
    if existing_user:
        return redirect(url_for("login", message="exists"))
    user_node = Node("User", name=name, email=email, phone=phone, password=password)
    graph.create(user_node)
    return redirect(url_for("login", message="signup_success"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    email = request.form["email"]
    password = request.form["password"]
    user = graph.evaluate("MATCH (u:User {email: $email, password: $password}) RETURN u", email=email, password=password)
    if user:
        session["user_email"] = email
        episode_id = str(uuid4())
        session["episode_id"] = episode_id
        timestamp = datetime.now().isoformat()
        episode_node = Node("Episode", episode_id=episode_id, start_time=timestamp)
        interaction_node = Node("Interaction", type="login", timestamp=timestamp)
        graph.create(episode_node)
        graph.create(interaction_node)
        graph.create(Relationship(episode_node, "HAS_INTERACTION", interaction_node))
        graph.create(Relationship(user, "PARTICIPATED_IN", episode_node))
        return redirect(url_for("index"))
    else:
        return "Invalid credentials. <a href='/login'>Try again</a>"

@app.route("/logout")
def logout():
    email = session.get("user_email")
    episode_id = session.get("episode_id")
    if episode_id:
        episode_node = graph.evaluate("MATCH (e:Episode {episode_id: $eid}) RETURN e", eid=episode_id)
        if episode_node:
            logout_time = datetime.now().isoformat()
            episode_node["end_time"] = logout_time
            graph.push(episode_node)
            logout_interaction = Node("Interaction", type="logout", timestamp=logout_time)
            graph.create(logout_interaction)
            graph.create(Relationship(episode_node, "HAS_INTERACTION", logout_interaction))
    session.clear()
    return redirect(url_for("login"))

# 🆕 New route to delete all Neo4j nodes
@app.route("/delete_all_nodes", methods=["POST"])
def delete_all_nodes():
    if not is_logged_in():
        return jsonify({"status": "unauthorized"}), 401
    try:
        graph.run("MATCH (n) DETACH DELETE n")
        return jsonify({"status": "success", "message": "All nodes deleted from Neo4j."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.errorhandler(404)
def not_found_error(error):
    return "This route is not found. Please check the URL.", 404

if __name__ == "__main__":
    app.run(debug=True, port=5050)
