from flask import Flask, request, jsonify, send_from_directory, send_file
import os
import io
import wave
import base64
import speech_recognition as sr
from gtts import gTTS
from pydub import AudioSegment
from chatbot_module import SmartChatBot  # ✅ import the chatbot class

# Instantiate chatbot
myChatbot = SmartChatBot()

app = Flask(__name__)

# ----------------------------
# Configuration
# ----------------------------
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

FIXED_FILENAME = "latest_audio.raw"
TTS_FILENAME = "tts_latest.mp3"

# ----------------------------
# /upload endpoint
# ----------------------------
@app.route('/upload', methods=['POST'])
def upload():
    audio_data = request.get_data()
    if not audio_data:
        return jsonify({"error": "No audio data received"}), 400

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], FIXED_FILENAME)
    try:
        with open(file_path, 'wb') as f:
            f.write(audio_data)
        print(f"Saved audio file as: {file_path}")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return jsonify({
        "message": "File uploaded successfully",
        "filename": FIXED_FILENAME
    }), 200

# ----------------------------
# /download_latest endpoint
# ----------------------------
@app.route('/download_latest', methods=['GET'])
def download_latest():
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], FIXED_FILENAME)
    if not os.path.exists(file_path):
        return jsonify({"error": "No audio file found"}), 404
    return send_from_directory(app.config['UPLOAD_FOLDER'], FIXED_FILENAME, as_attachment=True)

# ----------------------------
# /process_audio_chat endpoint
# ----------------------------
@app.route('/process_audio_chat', methods=['POST'])
def process_audio_chat():
    audio_data = request.get_data()
    if not audio_data:
        return jsonify({"error": "No audio data received"}), 400

    # Wrap raw audio in a WAV header
    wav_io = io.BytesIO()
    try:
        with wave.open(wav_io, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(1)  # 8-bit
            wf.setframerate(8000)
            wf.writeframes(audio_data)
    except Exception as e:
        return jsonify({"error": "Failed to create WAV: " + str(e)}), 500

    wav_io.seek(0)
    recognizer = sr.Recognizer()
    try:
        with sr.AudioFile(wav_io) as source:
            audio_record = recognizer.record(source)
        recognized_text = recognizer.recognize_google(audio_record)
    except Exception as e:
        recognized_text = "Error in speech recognition: " + str(e)

    # ✅ Normalize text before passing to AIML
    cleaned_text = recognized_text.lower().strip().replace("?", "")
    chatbot_response = myChatbot.handle_command(cleaned_text)

    return jsonify({
        "recognized_text": recognized_text,
        "chatbot_response": chatbot_response
    }), 200

# ----------------------------
# /process_audio_chat_tts endpoint
# ----------------------------
@app.route('/process_audio_chat_tts', methods=['POST'])
def process_audio_chat_tts():
    audio_data = request.get_data()
    if not audio_data:
        return jsonify({"error": "No audio data received"}), 400

    wav_io = io.BytesIO()
    try:
        with wave.open(wav_io, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(1)
            wf.setframerate(8000)
            wf.writeframes(audio_data)
    except Exception as e:
        return jsonify({"error": "Failed to create WAV: " + str(e)}), 500

    wav_io.seek(0)
    recognizer = sr.Recognizer()
    try:
        with sr.AudioFile(wav_io) as source:
            audio_record = recognizer.record(source)
        recognized_text = recognizer.recognize_google(audio_record)
    except Exception as e:
        recognized_text = "Error in speech recognition: " + str(e)

    # ✅ Normalize before passing to AIML
    cleaned_text = recognized_text.lower().strip().replace("?", "")
    chatbot_response = myChatbot.handle_command(cleaned_text)

    try:
        tts = gTTS(text=chatbot_response, lang='en')
        tts_io = io.BytesIO()
        tts.write_to_fp(tts_io)
        tts_io.seek(0)
        tts_audio_bytes = tts_io.read()

        tts_file_path = os.path.join(app.config['UPLOAD_FOLDER'], TTS_FILENAME)
        with open(tts_file_path, "wb") as f:
            f.write(tts_audio_bytes)

        encoded_tts_audio = base64.b64encode(tts_audio_bytes).decode('utf-8')
    except Exception as e:
        return jsonify({"error": "TTS conversion failed: " + str(e)}), 500

    return jsonify({
        "recognized_text": recognized_text,
        "chatbot_response": chatbot_response,
        "tts_audio": encoded_tts_audio,
        "tts_filename": TTS_FILENAME
    }), 200

# ----------------------------
# /download_tts endpoint
# ----------------------------
@app.route('/download_tts', methods=['GET'])
def download_tts():
    tts_file_path = os.path.join(app.config['UPLOAD_FOLDER'], TTS_FILENAME)
    if not os.path.exists(tts_file_path):
        return jsonify({"error": "TTS file not found"}), 404

    try:
        sound = AudioSegment.from_mp3(tts_file_path)
        sound = sound.set_frame_rate(8000).set_channels(1).set_sample_width(1)
        wav_io = io.BytesIO()
        sound.export(wav_io, format="wav")
        wav_io.seek(0)
        return send_file(wav_io, mimetype="audio/wav", as_attachment=True, download_name="tts_latest.wav")
    except Exception as e:
        return jsonify({"error": "Conversion error: " + str(e)}), 500

# ----------------------------
# Run the server
# ----------------------------
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
