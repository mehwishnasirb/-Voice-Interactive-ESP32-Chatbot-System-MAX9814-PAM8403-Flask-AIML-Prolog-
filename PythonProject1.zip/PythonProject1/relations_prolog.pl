:- discontiguous male/1.
:- discontiguous female/1.

% ------------------------------
% Gender Facts
% ------------------------------
male(mubarakali).
female(nasreenmubarak).
male(imran).
male(rizwan).
male(irfaan).
male(farhan).
female(sameena).
male(bashirahmed).
female(fehmidahbegum).
male(muaaz).
male(talha).
male(noorulhassan).
female(neara).
female(rubina).
female(zuhaa).

male(hamza).
male(zain).
male(khalid).
female(sadiya).
female(fizzah).
female(kashaf).
female(saman).
male(mannan).

male(khubaib).
male(furqan).
male(arsalan).
male(riaz).
female(quratulain).
female(rashidah).
male(zaid).
male(fozan).
male(usaid).
male(zeyam).
male(ijaz).
female(khalidah).
male(naseh).
male(mohid).
male(aleem).
female(mehnaz).
female(israh).
female(izmah).
male(zafar).
female(farhat).
female(hamna).
female(suniza).
female(navera).
female(simal).


male(marajdin).
female(kursheed).
female(mehwish).
male(nasir).
male(alihamza).
female(anum).
male(muneeb).
female(komal).
male(sharjeel).
male(yawar).
female(zreena).
male(waseem).
female(sonia).
male(waleed).
female(rabia).
male(noman).
female(anam).
male(ahmad).
female(zunaira).
male(salman).
female(maryam).
male(asif).
female(yasmeen).
male(nabeel).
male(umer).
male(hassan).
male(abdulrehman).
female(meerab).
male(anwar).
female(asfa).
female(ayesha).
male(ali).
male(ataulah).
male(hussan).
female(fatima).
female(nasreen).
male(naheed).
female(javed).
male(kashif).
female(noreen).
male(kamran).
female(aneesa).
male(tamoor).
female(nazia).
male(shanawaz).
female(shenaz).
female(rozeena).
female(vaneeza).
female(aysha).
female(saima).
female(urooj).
male(abid).
male(sajid).
female(faiza).
female(falak).
male(asad).
female(anmol).
female(wafa).
male(hammad).
male(tariq).
male(khalil).
male(irfan).
male(asef).
male(haseeb).
male(hasan).
male(mohsin).
male(umar).
female(zoona).
male(azan).
male(subhan).
female(naima).
female(horiya).
female(anisha).
female(neesa).
male(bazil).
female(sajal).
female(zeemal).
male(ayan).
male(ahmed).

% ----------- Parent Relationships ----------
parent(mubarakali, imran).
parent(nasreenmubarak, imran).

parent(mubarakali, rizwan).
parent(nasreenmubarak, rizwan).

parent(mubarakali, irfaan).
parent(nasreenmubarak, irfaan).

parent(mubarakali, farhan).
parent(nasreenmubarak, farhan).

parent(mubarakali, rubina).
parent(nasreenmubarak, rubina).

parent(mubarakali, sameena).
parent(nasreenmubarak, sameena).

parent(bashirahmed, noorulhassan).
parent(fehmidahbegum, noorulhassan).

parent(bashirahmed, khalid).
parent(fehmidahbegum, khalid).

parent(bashirahmed, rashidah).
parent(fehmidahbegum, rashidah).

parent(bashirahmed, khalidah).
parent(fehmidahbegum, khalidah).

parent(bashirahmed, farhat).
parent(fehmidahbegum, farhat).

parent(bashirahmed, mehnaz).
parent(fehmidahbegum, mehnaz).

parent(noorulhassan, muaaz).
parent(rubina, muaaz).

parent(noorulhassan, neara).
parent(rubina, neara).

parent(noorulhassan, talha).
parent(rubina, talha).

parent(noorulhassan, zuhaa).
parent(rubina, zuhaa).

parent(khalid, hamza).
parent(sadiya, hamza).

parent(khalid, zain).
parent(sadiya, zain).

parent(khalid, fizzah).
parent(sadiya, fizzah).

parent(khalid, kashaf).
parent(sadiya, kashaf).

parent(riaz, furqan).
parent(rashidah, furqan).

parent(riaz, quratulain).
parent(rashidah, quratulain).

parent(riaz, khubaib).
parent(rashidah, khubaib).

parent(riaz, arsalan).
parent(rashidah, arsalan).

parent(ijaz, fozan).
parent(khalidah, fozan).

parent(ijaz, usaid).
parent(khalidah, usaid).

parent(ijaz, zeyam).
parent(khalidah, zeyam).

parent(zafar, hamna).
parent(farhat, hamna).

parent(zafar, navera).
parent(farhat, navera).

parent(zafar, suniza).
parent(farhat, suniza).

parent(zafar, simal).
parent(farhat, simal).

parent(aleem, naseh).
parent(mehnaz, naseh).

parent(aleem, israh).
parent(mehnaz, israh).

parent(aleem, mohid).
parent(mehnaz, mohid).

parent(aleem, izmah).
parent(mehnaz, izmah).

parent(marajdin, yawar).
parent(kursheed, yawar).

parent(marajdin, nasir).
parent(kursheed, nasir).

parent(marajdin, asif).
parent(kursheed, asif).

parent(marajdin, asfa).
parent(kursheed, asfa).

parent(marajdin, nasreen).
parent(kursheed, nasreen).

parent(marajdin, naheed).
parent(kursheed, naheed).

parent(shanawaz, rozeena).
parent(shenaz, rozeena).

parent(shanawaz, anum).
parent(shenaz, anum).

parent(shanawaz, vaneeza).
parent(shenaz, vaneeza).

parent(shanawaz, aysha).
parent(shenaz, aysha).

parent(shanawaz, saima).
parent(shenaz, saima).

parent(shanawaz, urooj).
parent(shenaz, urooj).

parent(shanawaz, abid).
parent(shenaz, abid).

parent(shanawaz, sajid).
parent(shenaz, sajid).

parent(hammad, asad).
parent(rozeena, asad).

parent(hammad, anmol).
parent(rozeena, anmol).

parent(hammad, wafa).
parent(rozeena, wafa).

parent(nasir, mehwish).
parent(anum, mehwish).

parent(nasir, muneeb).
parent(anum, muneeb).

parent(nasir, alihamza).
parent(anum, alihamza).

parent(nasir, sharjeel).
parent(anum, sharjeel).

parent(tariq, hasan).
parent(vaneeza, hasan).

parent(tariq, haseeb).
parent(vaneeza, haseeb).

parent(tariq, mohsin).
parent(vaneeza, mohsin).

parent(tariq, umar).
parent(vaneeza, umar).

parent(khalil, azan).
parent(ayesha, azan).

parent(khalil, zoona).
parent(ayesha, zoona).

parent(irfan, subhan).
parent(saima, subhan).

parent(irfan, naima).
parent(saima, naima).

parent(asef, horiya ).
parent(urooj, horiya).

parent(asef, anisha ).
parent(urooj, anisha).

parent(asef, neesa ).
parent(urooj, neesa).

parent(abid, bazil ).
parent(faiza, bazil).

parent(abid, sajal ).
parent(faiza, sajal).

parent(abid, zeemal ).
parent(faiza, zeemal).

parent(sajid, ayan ).
parent(falak, ayan ).

parent(yawar, waseem).
parent(zreena, waseem).

parent(yawar, waleed).
parent(zreena, waleed).

parent(yawar, ahmad).
parent(zreena, ahmad).

parent(yawar, noman).
parent(zreena, noman).

parent(yawar, salman).
parent(zreena, salman).

parent(asif, nabeel).
parent(yasmeen, nabeel).

parent(asif, umer).
parent(yasmeen, umer).

parent(asif, abdulrehman).
parent(yasmeen, abdulrehman).

parent(asif, hassan).
parent(yasmeen, hassan).

parent(asif, meerab).
parent(yasmeen, meerab).

parent(anwar, ayesha).
parent(asfa, ayesha).

parent(anwar, ali).
parent(asfa, ali).

parent(ataulah, mohid).
parent(nasreen, mohid).

parent(ataulah, hussan).
parent(nasreen, hussan).

parent(ataulah, fatima).
parent(nasreen, fatima).

parent(javed, kashif).
parent(naheed, kashif).

parent(javed, kamran).
parent(naheed, kamran).

parent(javed, tamoor).
parent(naheed, tamoor).

parent(javed, nazia).
parent(naheed, nazia).

parent(javed, rabia).
parent(naheed, rabia).

parent(muneeb, ahmed).
parent(komal, ahmed).


% ------------------------------
% Marriage Facts
% ------------------------------
marriage(mubarakali, nasreenmubarak).
marriage(bashirahmed, fehmidahbegum).
marriage(noorulhassan, rubina).
marriage(khalid, sadiya).
marriage(riaz, rashidah).
marriage(ijaz, khalidah).
marriage(zafar, farhat).
marriage(aleem, mehnaz).
marriage(hamza, neara).
marriage(furqan, hamna).
marriage(zain, saman).
marriage(mannan, fizzah).
marriage(marajdin, kursheed).
marriage(shanawaz, shenaz).
marriage(hammad, rozeena).
marriage(tariq, vaneeza).
marriage(khalil, aysha).
marriage(irfan, saima).
marriage(asef, urooj).
marriage(abid, faiza).
marriage(sajid, falak).
marriage(nasir, anum).
marriage(muneeb, komal).
marriage(yawar, zreena).
marriage(waseem, sonia).
marriage(waleed, rabia).
marriage(noman, anam).
marriage(ahmad, zunaira).
marriage(salman, maryam).
marriage(asif, yasmeen).
marriage(anwar, asfa).
marriage(ataulah, nasreen).
marriage(javed, naheed).


% ------------------------------
% Age & Marriage Eligibility
% ------------------------------
age_of(mubarakali, 90).
age_of(nasreenmubarak, 89).
age_of(imran, 68).
age_of(rizwan, 71).
age_of(irfaan, 45).
age_of(farhan, 78).
age_of(sameena, 50).
age_of(bashirahmed, 98).
age_of(fehmidahbegum, 96).
age_of(muaaz, 22).
age_of(talha, 20).
age_of(noorulhassan, 53).
age_of(hamza, 30).
age_of(zain, 28).
age_of(khalid, 58).
age_of(mannan, 33).
age_of(khubaib, 25).
age_of(furqan, 36).
age_of(arsalan, 29).
age_of(riaz, 62).
age_of(zaid, 26).
age_of(fozan, 19).
age_of(usaid, 17).
age_of(zeyam, 15).
age_of(ijaz, 52).
age_of(naseh, 21).
age_of(mohid, 19).
age_of(aleem, 49).
age_of(zafar, 51).

age_of(neara, 26).
age_of(rubina, 47).
age_of(zuhaa, 20).
age_of(sadiya, 50).
age_of(fizzah, 27).
age_of(kashaf, 23).
age_of(saman, 25).
age_of(quratulain, 22).
age_of(rashidah, 48).
age_of(khalidah, 46).
age_of(farhat, 45).
age_of(mehnaz, 44).
age_of(hamna, 24).
age_of(navera, 21).
age_of(suniza, 19).
age_of(simal, 17).
age_of(israh, 20).
age_of(izmah, 18).

age_of(mehwish, 22).
age_of(alihamza, 27).
age_of(nasir, 55).
age_of(muneeb, 29).
age_of(komal, 25).
age_of(anum, 49).
age_of(sharjeel, 17).
age_of(yawar, 68).
age_of(zreena, 71).
age_of(waseem, 38).
age_of(sonia, 35).
age_of(waleed, 36).
age_of(rabia, 30).
age_of(ahmad, 33).
age_of(zunaira, 30).
age_of(noman, 32).
age_of(anam, 29).
age_of(salman, 31).
age_of(maryam, 29).
age_of(asif, 51).
age_of(yasmeen, 56).
age_of(nabeel, 26).
age_of(umer, 24).
age_of(hassan, 23).
age_of(abdulrehman, 22).
age_of(meerab, 18).
age_of(anwar, 43).
age_of(asfa, 42).
age_of(ali, 13).
age_of(ayesha, 16).
age_of(ataulah, 46).
age_of(nasreen, 45).
age_of(mohid, 12).
age_of(hussan, 23).
age_of(fatima, 15).
age_of(javed, 58).
age_of(naheed, 54).
age_of(kashif, 40).
age_of(noreen, 33).
age_of(kamran, 38).
age_of(aneesa, 31).
age_of(tamoor, 32).
age_of(nazia, 30).
age_of(marajdin, 98).
age_of(kursheed, 96).
age_of(shanawaz, 82).
age_of(shenaz, 80).
age_of(rozeena, 59).
age_of(hammad, 61).
age_of(asad, 33).
age_of(anmol, 31).
age_of(wafa, 21).
age_of(vaneeza, 51).
age_of(tariq, 61).
age_of(hasan, 29).
age_of(haseeb, 28).
age_of(mohsin, 23).
age_of(umar, 19).
age_of(khalil, 48).
age_of(aysha, 42).
age_of(azan, 26).
age_of(zoona, 24).
age_of(saima, 39).
age_of(irfan, 43).
age_of(subhan, 18).
age_of(naima, 15).
age_of(asef, 62).
age_of(urooj, 39).
age_of(horiya, 18).
age_of(anisha, 16).
age_of(neesa, 12).
age_of(abid, 36).
age_of(faiza, 32).
age_of(bazil, 12).
age_of(sajal, 10).
age_of(zeemal, 5).
age_of(sajid, 34).
age_of(falak, 30).
age_of(ayan, 6).
age_of(ahmed, 1).
% ----------- Derived Relationships ----------
father(X, Y) :- male(X), parent(X, Y).
mother(X, Y) :- female(X), parent(X, Y).

sibling(X, Y) :- parent(Z, X), parent(Z, Y), X \= Y.
brother(X, Y) :- male(X), sibling(X, Y).
sister(X, Y) :- female(X), sibling(X, Y).

grandparent(X, Y) :- parent(X, Z), parent(Z, Y).
grandfather(X, Y) :- male(X), grandparent(X, Y).
grandmother(X, Y) :- female(X), grandparent(X, Y).

uncle(X, Y) :- male(X), sibling(X, Z), parent(Z, Y).
aunt(X, Y) :- female(X), sibling(X, Z), parent(Z, Y).

chacha(X, Y) :- male(X), sibling(X, Z), parent(Z, Y), father(Z, Y).
mamu(X, Y) :- male(X), sibling(X, Z), mother(Z, Y).
khala(X, Y) :- female(X), sibling(X, Z), mother(Z, Y).
phuphi(X, Y) :- female(X), sibling(X, Z), father(Z, Y).

cousin(X, Y) :- parent(P1, X), parent(P2, Y), sibling(P1, P2), X \= Y.

% ----------- Marriage Restrictions ----------
cannot_marry(X, Y) :- sibling(X, Y).
cannot_marry(X, Y) :- parent(X, Y).
cannot_marry(X, Y) :- parent(Y, X).
cannot_marry(X, Y) :- grandparent(X, Y).
cannot_marry(X, Y) :- grandparent(Y, X).



eligible_for_marriage(X) :-
    age_of(X, Age),
    Age >= 18.

can_marry(X, Y) :-
    eligible_for_marriage(X),
    eligible_for_marriage(Y),
    \+ cannot_marry(X, Y),
    X \= Y.

